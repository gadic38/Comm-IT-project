import boto3

def lambda_handler(event, context):
    dynamodb_table_name = 'dynamousere'
    
    username_primary_key = 'username'
    
   
    parameter_store_path = '/Username'
    
   
    if 'Records' in event:
        
        for record in event['Records']:
            
            if record['eventName'] == 'INSERT':
                
                new_user = record['dynamodb']['NewImage']
                
                
                username = new_user['username']['S']  
                
                
                ssm = boto3.client('ssm')
                ssm.put_parameter(
                    Name=parameter_store_path,
                    Value=username,
                    Type='String',
                    Tier='Standard',  
                    Overwrite=True
                )
        
        return {
            'statusCode': 200,
            'body': 'New users saved to Parameter Store.'
        }
    else:
        return {
            'statusCode': 400,
            'body': 'Invalid event data. Missing "Records" key.'
        }