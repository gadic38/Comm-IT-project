import boto3
import datetime

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('dynamousere')

def lambda_handler(event, context):
    print(event)
    # TODO implement
    username = event['userName']
    useremail = event['request']['userAttributes']['email']
    
    # Add a time stamp using the current date and time
    current_timestamp = datetime.datetime.utcnow().isoformat()

    # Add the time stamp along with the 'username' and 'useremail' attributes
    response = table.put_item(Item={
        'username': username,
        'useremail': useremail,
        'timestamp': current_timestamp
    })

    return event