import boto3

def get_parameter_from_store(parameter_name):
    # Create an SSM client
    ssm = boto3.client('ssm')

    # Get the parameter value from Parameter Store
    response = ssm.get_parameter(
        Name=parameter_name,
        WithDecryption=False  # Set to True if the parameter is encrypted
    )

    return response['Parameter']['Value']

def lambda_handler(event, context):
    # Replace 'YourParameterStorePath/Username' with the actual parameter store path where you saved the username
    parameter_name = '/Username'

    try:
        parameter_value = get_parameter_from_store(parameter_name)
        message = f"Hello {parameter_value}!"
        status_code = 200
    except Exception as e:
        message = f"Error: {str(e)}"
        status_code = 500

    return {
        'statusCode': status_code,
        'body': message
    }