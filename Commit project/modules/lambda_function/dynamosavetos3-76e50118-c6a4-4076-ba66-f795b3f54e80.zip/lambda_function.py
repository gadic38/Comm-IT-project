import boto3
import json

def lambda_handler(event, context):
    
    dynamodb = boto3.resource('dynamodb')
    s3 = boto3.resource('s3')
    
    
    table_name = 'dynamousere'
    table = dynamodb.Table(table_name)
    
    response = table.scan()
    users = response['Items']
    
    for user in users:
        username = user['username']
        timestamp = user['timestamp']  
        
        
        content = str(timestamp)
        
        
        bucket_name = 's3testcommit'
        key = f'{username}.txt'
        obj = s3.Object(bucket_name, key)
        obj.put(Body=content)
        
    return {
        'statusCode': 200,
        'body': json.dumps('Files saved to S3 successfully!')
    }
